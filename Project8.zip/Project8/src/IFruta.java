interface IFruta {
    double valorPago();
    String getName();
}
